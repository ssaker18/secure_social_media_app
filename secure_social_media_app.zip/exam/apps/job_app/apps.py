from django.apps import AppConfig


class JobAppConfig(AppConfig):
    name = 'job_app'
