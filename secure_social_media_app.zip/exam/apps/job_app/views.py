from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
import re
import bcrypt
from .models import User, Job

def index(request):
    return render(request, 'job_app/index.html')

def register(request):
    errors=User.objects.validator(request.POST)
    #remember that request.post returns a dictionary with the form's input names as the keys!
    if len(errors)>0:
        for val in errors:
            messages.error(request, val, extra_tags='register')
        return redirect('/')
    else:
        new_user=User.objects.register(request.POST)
    request.session['id']=new_user.id
    return redirect('/dashboard')

def success(request):
    if not 'id' in request.session:
        return redirect('/')
    else:
        current_user=User.objects.get(id=request.session['id'])
        context={
            "first_name":current_user.first_name,
            "jobs":Job.objects.all(),
            "edit_link":"Edit",
            "delete_link":"Remove",
        }
        return render(request, 'job_app/success.html', context)

def logout(request):
    request.session.clear()
    return redirect('/')

def login(request):
    check_user= User.objects.authenticate(request.POST['email'], request.POST['password'])
    if check_user:
        current_user= User.objects.get(email=request.POST['email'])
        request.session['id']=current_user.id
        return redirect('/dashboard')
    else:
        messages.error(request, 'Invalid Email/Password', extra_tags='login')
        return redirect('/')

def new_job(request):
    if not 'id' in request.session:
        return redirect('/')
    else:
        current_user=User.objects.get(id=request.session['id'])
        context={
            "first_name":current_user.first_name,
        }
        return render(request, 'job_app/create.html', context)

def process_job(request):
    errors=Job.objects.validator(request.POST)
    if len(errors)>0:
        for val in errors:
            messages.error(request, val, extra_tags='job')
        return redirect('/jobs/new')
    else:
        new_job=Job.objects.add_job(request.POST, user_id =request.session['id'])
        
    return redirect('/dashboard')

def edit_job(request, job_id):
    if not 'id' in request.session:
        return redirect('/')
    else:
        current_user=User.objects.get(id=request.session['id'])
        context={
            "first_name":current_user.first_name,
            "job":Job.objects.get(id=job_id),
        }
        return render(request, 'job_app/edit.html', context)

def update(request, job_id):
    errors=Job.objects.validator(request.POST)
    if len(errors)>0:
        for val in errors:
            messages.error(request, val, extra_tags='job')
        return redirect(f'/jobs/edit/{job_id}')
    else:
        updated_job=Job.objects.edit_job(request.POST, job_id)
        return redirect('/dashboard')

def delete(request, job_id):
    if not 'id' in request.session:
        return redirect('/')
    else:
        job_to_delete=Job.objects.get(id=job_id)
        job_to_delete.delete()
        return redirect('/dashboard')
    
def view(request, job_id):
    if not 'id' in request.session:
        return redirect('/')
    else:
        current_user=User.objects.get(id=request.session['id'])
        job_to_view=Job.objects.get(id=job_id)
        context={
            "first_name":current_user.first_name,
            "job":job_to_view,
        }
        return render(request, 'job_app/view.html', context)

# def destruction(request):
#     all_jobs_must_perish=Job.objects.all()
#     all_jobs_must_perish.delete()
#     return redirect('/dashboard')